-- PL --

Załącznik do pracy dyplomowej pt.: 
MODELOWANIE OŚWIETLENIA Z WYKORZYSTANIEM ŚWIATŁA POZYCYJNEGO W OPENGL.

Przed uruchomieniem należy zainstalować pakiet redystrybucyjny programu
Visual Studio 2019.

Pakiet dostępny do pobrania pod tym linkiem:
https://aka.ms/vs/16/release/vc_redist.x86.exe


-- ENG -- 

This is the attachment to thesis:
MODELING OF ILLUMINATION USING POINT LIGHT IN OPENGL

Before first run, please install the package "Visual C++ Redistributable 2019".

Available under the address:
https://aka.ms/vs/16/release/vc_redist.x86.exe